//
//  LearningTrailProtocols.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import UIKit

/*
protocol LearningTrailPresenterDelegate {
    func didLoadTrail(learningTrail: LearningTrail)
    func didShowStep(learningStep: LearningStep, at index: Int)
}

protocol LearningStepPresenterDelegate {
    func didLoadStep(learningTrail: LearningTrail)
    func didDiscloseBlock(learningBlock: LearningBlock, at index: Int)
    func didInteractWithBlock(learningBlock: LearningBlock, at index: Int)
    func didCompleteResponseBlock(learningBlock: LearningBlock, at index: Int)
}
*/


