
import SpriteKit
import Foundation
import AVFoundation

// Essa é a cena interativa que é exibida
class DragScene: SKScene, SKPhysicsContactDelegate {
    
    // Cria uma lista de fotos. Ela começa vazia
    var pictures = [SKSpriteNode]()
    var dragging: SKSpriteNode! // Variável para guardar a foto que está sendo arrastada
    var zTop: CGFloat = 1
    
    // Essa parte do código é executada logo que a cena começa
    override func didMove(to view: SKView) {

        // Vamos começar criando a imagem de background
        let background = SKSpriteNode(imageNamed: "wall")
        
        // Centralizar a imagem (metade da largura e altura da tela)
        background.position = CGPoint(x: 375, y: 600)
        
        // Agora vamos colocar o background na cena
        self.addChild(background)
        
        // Agora vamos adicionar todas as fotos que importamos para o projeto
        for i in 1 ... 16 {
            // Nome da imagem a partir do índice
            let name = "F\(i)" // O resultado disso é F1, F2, F3...
            let picture = SKSpriteNode(imageNamed: name) // Usamos o nemo gerado para carregar a foto no código
            
            // Colocamos a foto na nossa lista de fotos para podermos acessá-la depois
            pictures.append(picture)
            
            // Altera a escala para deixar a foto menor
            picture.setScale(0.2)
            
            // Posição aleatória
            picture.position = CGPoint(x: CGFloat.random(in: 275...475), y: CGFloat.random(in: 150...200))
            
            // Rotação aleatória
            picture.zRotation = CGFloat.random(in: -0.1...0.1)
            
            // Posição Z para a imagem ficar por cima de todas as outras
            picture.zPosition = zTop
            zTop += 1 // Aumenta 1 na variável para que seja sempre superior a anterior 
            
            // Adicionamos a foto à cena
            self.addChild(picture)
        }
    }
    
    // Função que recebe a coordenada do ponto clicado na tela
    func touchDown(atPoint pos : CGPoint) {
        
        // No momento do clique na tela verificamos se esse click ocorreu sobre uma das imagens
        for picture in pictures.reversed() { // Reversed para começarmos pelas últimas, que são as que estão no topo da pilha
            if picture.contains(pos) { // Verifica se a imagem contêm a coordenada do click
                dragging = picture // Define que a foto arrastada é a que contêm o ponto clicado
                // Altera a escala da imagem
                picture.setScale(0.5)
                // Coloca a imagem no topo
                picture.zPosition = zTop
                zTop += 1
                return // Interrompe a busca quando encontra a imagem
            }
        }
    }
    
    // Função que recebe a coordenada no toque ao movimentar o dedo ou cursor do mouse sobre a tela 
    func touchMoved(toPoint pos : CGPoint) {
        // Nesse momento verificamos se alguma imagem está sendo arrastada
        if dragging != nil {
            // Então alteramos a posição da imagem para coincidir com a posição do toque
            dragging.position = pos
        }
    }
    
    // Função que recebe a coordenada do dedo ou cursor do mouse no momento em que o dedo sai da tela ou o botão do mouse é solto 
    func touchUp(atPoint pos : CGPoint) {
        // Nesse momento verificamos se alguma imagem está sendo arrastada
        if dragging != nil {
            // Deixamos um pouco menor a imagem que estava sendo arrastada
            dragging.setScale(0.3)
            
            // Removemos a imagem da variável dragging
            dragging = nil
        }
    }
    
    
    // Essa parte cuida de monitorar os toques ou cliques na tela. Cada vez que isso acontece essa função chama a nossa outra função touchDown passando a posição exata do toque na tela. Normalmente não precisamos mexer aqui.
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    // Muito parecido com o código acima. A diferença é que essa função monitora o movimento do doque na tela 
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchMoved(toPoint: t.location(in: self)) }
    }
    
    // Aqui é monitorada a saída do dedo dda tela ou o término do click do mouse
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
}
