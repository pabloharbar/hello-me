
import Foundation
import SpriteKit

public class PhysicsViewController : UIViewController {
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let view = SKView()
        
        // Aqui é criada uma cena com as dimensões 800 x 800 e exibida na tela. Para ver o funcionamento dessa cena veja o arquivo PhysicsScene.swift
        var scene = PhysicsScene(size: CGSize(width: 800, height: 800))
        scene.scaleMode = .aspectFit
        view.presentScene(scene)
        
        self.view = view
        
    }
}
